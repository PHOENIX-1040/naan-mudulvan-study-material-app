package com.example.owlapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFF411A25)
val Purple500 = Color(0xFFBD92F8)
val Purple700 = Color(0xFF006BA4)
val Teal200 = Color(0xFFF4511E)